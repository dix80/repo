import os
import zipfile
import urllib.request
import xbmcgui
import shutil
import time
import xml.etree.ElementTree as ET
import subprocess

SKIN_NAME = "skin.arctic.zephyr.2.resurrection"
LANGUAGE_CODE = "resource.language.it_it"

# Percorsi aggiornati
BASE_PATH = "/storage/emulated/0/Android/data/org.xbmc.kodi/files"
ZIP_PATH = os.path.join(BASE_PATH, "Build-Kodi-android.zip")
TEMP_PATH = os.path.join(BASE_PATH, "Temp")
KODI_PATH = os.path.join(BASE_PATH, ".kodi")

# Nuovo link per il download
DOWNLOAD_URL = "https://www.dropbox.com/scl/fi/q6td4lfn3kgen23qj089b/android.zip?rlkey=um6ax9ag5n5nhjvdhiyb8eu71&st=n63hd18a&dl=1"

def download_file(url, dest_path):
    dialog = xbmcgui.DialogProgress()
    dialog.create("Download in corso", "Sto scaricando il file...")
    try:
        urllib.request.urlretrieve(url, dest_path, reporthook=lambda count, block_size, total_size: dialog.update(int(count * block_size * 100 / total_size)))
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Errore", f"Errore durante il download: {str(e)}")
        return False
    dialog.close()
    return True

def extract_zip(zip_path, extract_to):
    dialog = xbmcgui.DialogProgress()
    dialog.create("Estrazione in corso", "Sto estraendo il file...")
    try:
        if os.path.exists(TEMP_PATH):
            shutil.rmtree(TEMP_PATH, ignore_errors=True)
        os.makedirs(TEMP_PATH, exist_ok=True)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(TEMP_PATH)
            dialog.update(100)
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Errore", f"Errore durante l'estrazione: {str(e)}")
        return False
    dialog.close()
    return True

def replace_kodi_folder():
    dialog = xbmcgui.DialogProgress()
    dialog.create("Trasferimento in corso", "Sto trasferendo i file...")
    try:
        # Cancella la cartella .kodi se esiste
        if os.path.exists(KODI_PATH):
            shutil.rmtree(KODI_PATH, ignore_errors=True)
            time.sleep(2)

        # Sposta i file dalla cartella temporanea a BASE_PATH
        for item in os.listdir(TEMP_PATH):
            src = os.path.join(TEMP_PATH, item)
            dst = os.path.join(BASE_PATH, item)

            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)

        # Rimuove la cartella temporanea
        shutil.rmtree(TEMP_PATH, ignore_errors=True)
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Errore", f"Errore durante il trasferimento dei file: {str(e)}")
        return False
    dialog.close()
    return True

def is_kodi_running():
    try:
        process = subprocess.Popen(["ps", "-A"], stdout=subprocess.PIPE)
        output = process.communicate()[0]
        for line in output.splitlines():
            if b"org.xbmc.kodi" in line:
                return True
    except Exception as e:
        xbmcgui.Dialog().ok("Errore", f"Errore durante il controllo di Kodi: {str(e)}")
    return False

def close_kodi():
    try:
        if is_kodi_running():
            process = subprocess.Popen(["ps", "-A"], stdout=subprocess.PIPE)
            output = process.communicate()[0]
            for line in output.splitlines():
                if b"org.xbmc.kodi" in line:
                    pid = int(line.split()[1])
                    subprocess.run(["kill", "-9", str(pid)], check=True)
                    break
    except Exception as e:
        xbmcgui.Dialog().ok("Errore", f"Errore durante la chiusura di Kodi: {str(e)}")

def install_addon():
    if download_file(DOWNLOAD_URL, ZIP_PATH):
        if extract_zip(ZIP_PATH, BASE_PATH):
            if replace_kodi_folder():
                os.remove(ZIP_PATH)
                xbmcgui.Dialog().ok("Installazione Completata", "L'aggiornamento è stato completato. Kodi verrà chiuso, riavvialo per applicare le modifiche.")
                close_kodi()
                time.sleep(5)

install_addon()
